// src/app/api/genkit/[slug]/route.ts
import '@/ai/dev';
import { POST } from '@genkit-ai/next';

export { POST };
